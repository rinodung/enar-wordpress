<div class="search_block">
<form class="searchform" method="get" action="<?php echo esc_url(home_url()); ?>">
    <input class="serch_input" type="search" name="s" id="s" placeholder="<?php esc_html_e( 'Search...', 'enar'); ?>" />
    <button type="submit" id="searchsubmit" class="search_btn animate">
            <i class="ico-search8"></i>
    </button>
    <div class="clear"></div>
</form>
</div>