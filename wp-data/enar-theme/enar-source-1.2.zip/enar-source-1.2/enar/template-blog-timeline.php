<?php
/*
Template Name: Blog Timeline
*/

get_template_part('includes/blog', 'masonry_timeline_grid_wrapper');