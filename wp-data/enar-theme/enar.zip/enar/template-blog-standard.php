<?php
/*
Template Name: Blog Standard
*/

get_template_part('includes/blog', 'standard_list_wrapper');