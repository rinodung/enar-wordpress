<?php
/*
Template Name: Portfolio Masonry Colored 3 Columns
*/
get_template_part('includes/blog', 'masonry_timeline_grid_wrapper');